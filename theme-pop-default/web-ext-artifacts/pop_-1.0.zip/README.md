Unofficial Firefox Theme based on the GTK3.2 styles of Pop!_OS.

Features a dark brown title bar with a light active tab and toolbar and orange and teal accents.

Based on Pop!_OS GTK Theme: https://github.com/pop-os/gtk-theme

Source code: https://github.com/Webricolage/firefox-theme-pop-os
