Unofficial Firefox Theme based on the GTK3.2 styles of Pop!_OS.
Features: brown title bar with a light toolbar and teal accents.

Source code: https://github.com/Webricolage/firefox-theme-pop-os
